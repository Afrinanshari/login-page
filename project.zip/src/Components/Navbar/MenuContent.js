export const MenuItem = [
    {
        title:'Home',
        link: "/",
        Cname: 'nav-links'
    },
    {
        title:'About',
        link: "/about",
        Cname: 'nav-links'
    },
    {
        title:'Login',
        link: "/login",
        Cname: 'nav-links-important'
    },
    {
        title:'Signup',
        link: "/signup",
        Cname: 'nav-links-important'
    },
]