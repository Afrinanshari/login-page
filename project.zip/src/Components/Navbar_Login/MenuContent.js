export const MenuItem = [
    {
        title:'Home',
        link: "/question",
        Cname: 'nav-links'
    },
]